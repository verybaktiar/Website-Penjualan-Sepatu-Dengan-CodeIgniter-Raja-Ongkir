<?php 

class Auth extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Model_Auth');
	}
	function login()
	{
		checklog();
		#Meload view dari login
		$this->load->view('auth/login');
	}
	#Method cek login
	function ceklogin()
	{
	#menangkap data yang dikirim dari form login
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$login = $this->Model_Auth->getlogin($username,$password);
		$ceklogin = $login->num_rows();
		$datalogin = $login->row_array();
		$data = array(
			'id_user'=> $datalogin['id_user'],
			'nama_lengkap'=> $datalogin['nama_lengkap'],
			'username'=> $datalogin['username'],
			'password'=> $datalogin['password'],
			'kode_cabang'=> $datalogin['kode_cabang']		
		);
		$this->session->set_userdata($data);
		die;
		if($ceklogin == 1){
			redirect("dashboard");
		}else{
			$this->session->set_flashdata('msg', '
			<div class="alert alert-warning" role="alert">
			Username atau Password Salah
			</div>');
			redirect("auth/login");
		}
	}
}

