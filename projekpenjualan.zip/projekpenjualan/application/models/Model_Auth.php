<?php
class Model_Auth extends CI_Model
{
	#Membuat method pengecekan login data ke dalam database
	function getlogin($username,$password)
	{
		return $this->db->get_where('users',array('username' => $username,'password' => $password));
	}
}